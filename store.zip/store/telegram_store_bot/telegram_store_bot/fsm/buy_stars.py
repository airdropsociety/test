from aiogram.fsm.state import StatesGroup, State

class BuyStarsStates(StatesGroup):
    choosing_username = State()
    choosing_quantity = State()
    choosing_payment = State()
    confirming_order = State()
    last_message_id = State()  # Add this to track our message